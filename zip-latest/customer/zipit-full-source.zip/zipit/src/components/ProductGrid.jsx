import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import { getProductDeliveryTime } from '../utils/time';
import './ProductGrid.css';
import './ProductListPage.css';

const ProductGrid = ({ navigate, cart, updateCartQty }) => {
  const [categories, setCategories] = useState([]);
  const [gridProducts, setGridProducts] = useState([]);

  useEffect(() => {
    const fetchCats = async () => {
      const data = await db.categories.getAll();
      setCategories(data);
    };
    const fetchProds = async () => {
      const all = await db.products.getAll();
      setGridProducts(all.filter(p => p.is_grid));
    };
    fetchCats();
    fetchProds();
  }, []);

  return (
    <main className="product-grid-container">
      <section className="categories-section">
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16}}>
          <h2 className="section-title" style={{marginBottom: 0}}>Our Products Variety</h2>
          <span style={{color: 'var(--color-danger)', fontWeight: 600, fontSize: 13, cursor: 'pointer'}} onClick={() => navigate('categories')}>View All</span>
        </div>
        <div className="category-grid">
          {categories.slice(0, 8).map((cat, idx) => (
            <div key={cat.id || idx} className="category-item stagger-item" onClick={() => navigate('product-list', { category: cat.name, categoryId: cat.id, from: 'home' })}>
              <div className="category-image">
                <img src={cat.image_url} alt={cat.name} />
              </div>
              <span className="category-name">{cat.name}</span>
            </div>
          ))}
        </div>
      </section>

      {gridProducts.length > 0 && (
        <section className="grid-products-section" style={{marginTop: 32}}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16}}>
            <h2 className="section-title" style={{marginBottom: 0}}>Featured Products</h2>
          </div>
          <div className="product-list-grid">
            {gridProducts.map(prod => {
              const cartItem = cart.find(item => item.id === prod.id);
              const qty = cartItem ? cartItem.qty : 0;
              return (
                <div key={prod.id} className="bestseller-card stagger-item">
                  <div className="bestseller-img" style={{cursor: 'pointer', position: 'relative'}} onClick={() => navigate('product-list', { categoryId: prod.category_id, category: prod.categories?.name, from: 'home' })}>
                    {prod.sticker && <div className="product-sticker">{prod.sticker}</div>}
                    <img src={prod.image_url} alt={prod.name} />
                    {qty === 0 ? (
                      <button className="add-btn-small" onClick={(e) => { e.stopPropagation(); updateCartQty(prod, 1); }}>ADD</button>
                    ) : (
                      <div className="qty-control" onClick={(e) => e.stopPropagation()}>
                        <button onClick={(e) => { e.stopPropagation(); updateCartQty(prod, -1); }}>-</button>
                        <span>{qty}</span>
                        <button onClick={(e) => { e.stopPropagation(); updateCartQty(prod, 1); }}>+</button>
                      </div>
                    )}
                  </div>
                  <div className="bestseller-info">
                    <h3 className="item-name">{prod.name}</h3>
                    <div className="item-amount" style={{fontSize: 12, color: '#666', marginBottom: 4}}>{prod.amount}</div>
                    <div className="time-tag">⏱ {getProductDeliveryTime(prod.name)} MINS</div>
                    <div className="item-price">₹{prod.price}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </main>
  );
};

export default ProductGrid;
