import React, { useEffect } from 'react';
import './Toast.css';
import { Bell } from 'lucide-react';

const Toast = ({ message, title, onClose, visible }) => {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(() => {
        onClose();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  if (!visible) return null;

  return (
    <div className="toast-container fade-in-up" onClick={onClose}>
      <div className="toast-icon">
        <Bell size={20} color="#FFF" />
      </div>
      <div className="toast-content">
        <h4>{title}</h4>
        <p>{message}</p>
      </div>
    </div>
  );
};

export default Toast;
