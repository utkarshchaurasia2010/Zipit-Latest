import React from 'react';
import { ArrowLeft, CreditCard } from 'lucide-react';
import { db } from '../services/db';

const PaymentMethodsPage = ({ navigate }) => {
  const methods = db.paymentMethods.getAll();

  return (
    <div className="payment-methods-page">
      <header className="page-header">
        <button className="back-btn" onClick={() => navigate('profile')}><ArrowLeft size={24} color="var(--color-text)" /></button>
        <h2>Payment Methods</h2>
      </header>
      <div className="addresses-container">
        <div className="address-card">
          <div className="address-type">
            <CreditCard size={20} color="var(--color-success)" />
            <h4>UPI Apps</h4>
          </div>
          <p className="address-details">GPay, PhonePe, Paytm, Amazon Pay</p>
        </div>
        
        <div className="address-card">
          <div className="address-type">
            <CreditCard size={20} color="var(--color-text-light)" />
            <h4>Cash on Delivery</h4>
          </div>
          <p className="address-details">Pay when your order arrives</p>
        </div>
      </div>
    </div>
  );
};
export default PaymentMethodsPage;
