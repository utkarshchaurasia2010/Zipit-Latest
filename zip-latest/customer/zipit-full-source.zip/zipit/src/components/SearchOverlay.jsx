import React, { useState, useEffect } from 'react';
import { Search, ArrowLeft, Mic, Plus, X } from 'lucide-react';
import { db } from '../services/db';
import './SearchOverlay.css';

const SearchOverlay = ({ isOpen, onClose, cart, updateCartQty }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem('zipit_recent_searches');
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch(e) {}
    }
  }, []);

  const saveRecentSearch = (term) => {
    if (!term.trim()) return;
    const termLower = term.trim().toLowerCase();
    const filtered = recentSearches.filter(s => s.toLowerCase() !== termLower);
    const newSearches = [term.trim(), ...filtered].slice(0, 8); // Keep last 8
    setRecentSearches(newSearches);
    localStorage.setItem('zipit_recent_searches', JSON.stringify(newSearches));
  };

  const removeRecentSearch = (term, e) => {
    e.stopPropagation();
    const newSearches = recentSearches.filter(s => s !== term);
    setRecentSearches(newSearches);
    localStorage.setItem('zipit_recent_searches', JSON.stringify(newSearches));
  };

  useEffect(() => {
    if (!isOpen) {
      setQuery('');
      setResults([]);
    }
  }, [isOpen]);

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.trim().length > 0) {
        setLoading(true);
        const data = await db.products.search(query.trim());
        setResults(data);
        setLoading(false);
        // We only save to history if they pause typing for 1 second, or when they click a result (handled elsewhere)
      } else {
        setResults([]);
      }
    }, 500); // 500ms debounce
    
    return () => clearTimeout(timer);
  }, [query]);

  // Save to history when results load and there is a valid query
  useEffect(() => {
    if (query.trim() && !loading && results.length > 0) {
      const historyTimer = setTimeout(() => {
        saveRecentSearch(query);
      }, 1500);
      return () => clearTimeout(historyTimer);
    }
  }, [loading, results, query]);

  const getQty = (id) => {
    const item = cart?.find(c => c.id === id);
    return item ? item.qty : 0;
  };

  const handleTagClick = (tag) => {
    setQuery(tag);
  };

  if (!isOpen) return null;

  return (
    <div className="search-overlay">
      <div className="search-overlay-header">
        <button className="back-btn" onClick={onClose}><ArrowLeft size={24} color="var(--color-text)" /></button>
        <div className="search-input-box">
          <Search size={20} color="var(--color-text-light)" />
          <input 
            type="text" 
            placeholder="Search for groceries, snacks..." 
            autoFocus 
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <div className="divider"></div>
          <Mic size={20} color="#000" className="mic-icon" onClick={() => alert('Listening...')} />
        </div>
      </div>
      <div className="search-body">
        {!query ? (
          recentSearches.length > 0 ? (
            <div className="recent-searches">
              <h4>Recent Searches</h4>
              <div className="tag-list">
                {recentSearches.map(term => (
                  <span key={term} className="tag" onClick={() => handleTagClick(term)}>
                    {term}
                    <button className="remove-tag-btn" onClick={(e) => removeRecentSearch(term, e)}><X size={12} /></button>
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div className="empty-search-state">Search for your favorite products</div>
          )
        ) : loading ? (
          <p className="search-results-text">Searching for "{query}"...</p>
        ) : results.length === 0 ? (
          <p className="search-results-text">No products found for "{query}".</p>
        ) : (
          <div className="search-results-list">
            {results.map(item => {
              const qty = getQty(item.id);
              return (
                <div key={item.id} className="search-product-card">
                  <div className="search-product-img">
                    <img src={item.image_url} alt={item.name} />
                  </div>
                  <div className="search-product-info">
                    <h3 className="item-name">{item.name}</h3>
                    <div className="item-amount">{item.amount}</div>
                    <div className="item-price">₹{item.price}</div>
                  </div>
                  <div className="search-product-action">
                    {qty === 0 ? (
                      <button className="add-btn-plus-only" onClick={() => { saveRecentSearch(query); updateCartQty(item, 1); }}>
                        <Plus size={20} />
                      </button>
                    ) : (
                      <div className="search-qty-control">
                        <button onClick={() => updateCartQty(item, -1)}>-</button>
                        <span>{qty}</span>
                        <button onClick={() => updateCartQty(item, 1)}>+</button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
export default SearchOverlay;
