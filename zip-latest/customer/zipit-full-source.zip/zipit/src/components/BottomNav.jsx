import React from 'react';
import { Home, LayoutGrid, ShoppingBag, ShoppingCart } from 'lucide-react';
import './BottomNav.css';

const BottomNav = ({ activeTab, navigate, openCart, isNavHidden }) => {
  return (
    <nav className={`bottom-nav ${isNavHidden ? 'hidden' : ''}`}>
      <div className={`nav-item ${activeTab === 'home' ? 'active' : ''}`} onClick={() => navigate('home')}>
        <Home size={24} />
      </div>
      <div className={`nav-item ${activeTab === 'categories' ? 'active' : ''}`} onClick={() => navigate('categories')}>
        <LayoutGrid size={24} />
      </div>
      <div className={`nav-item ${activeTab === 'orders' ? 'active' : ''}`} onClick={() => navigate('orders')}>
        <ShoppingBag size={24} />
      </div>
      <div className="nav-item" onClick={openCart}>
        <ShoppingCart size={24} />
      </div>
    </nav>
  );
};

export default BottomNav;
