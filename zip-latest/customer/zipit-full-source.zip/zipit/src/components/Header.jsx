import React, { useState, useEffect } from 'react';
import { Search, ChevronDown, UserRound, Mic } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getCartDeliveryTime } from '../utils/time';
import './Header.css';

const Header = ({ time, onAddressClick, onSearchClick, onProfileClick, defaultAddress, isHome, isNavHidden, bgColor = 'transparent', cart }) => {
  const { theme } = useTheme();
  
  // Rotating search text
  const searchItems = ["'ice-cream'", "'milk'", "'bread'", "'eggs'", "'chips'", "'maggi'"];
  const [searchIndex, setSearchIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSearchIndex(prev => (prev + 1) % searchItems.length);
    }, 2000);
    return () => clearInterval(interval);
  }, []);
  const textColor = isHome || theme === 'dark' ? '#FFFFFF' : '#000000';
  const iconColor = textColor;

  const topOffset = isNavHidden ? '-96px' : '0px';

  return (
    <header className="app-header" style={{ background: bgColor, paddingBottom: '16px', top: topOffset }}>
      <div className="header-top" style={{ color: textColor }}>
        <div className="location-info" onClick={onAddressClick}>
          <div className="delivery-time">
            <strong>Zipit in</strong>
            <h1>{getCartDeliveryTime(cart) || time} minutes</h1>
          </div>
          <div className="address">
            {defaultAddress && defaultAddress.details ? (
              <><strong>{defaultAddress.type || 'Address'}</strong> - {defaultAddress.details.slice(0,25)}... <ChevronDown size={16} /></>
            ) : (
              <><strong>Location</strong> - Select Address <ChevronDown size={16} /></>
            )}
          </div>
        </div>
        <div className="profile-pic" onClick={onProfileClick}>
          <UserRound size={22} color="#FFFFFF" strokeWidth={1} />
        </div>
      </div>
      
      <div className="search-container" onClick={onSearchClick}>
        <Search size={20} color={theme === 'dark' ? '#9CA3AF' : '#6B7280'} />
        <div className="search-placeholder-wrapper">
          <span>Search for </span>
          <div className="animated-search-text">
            <span key={searchIndex} className="slide-up-text">{searchItems[searchIndex]}</span>
          </div>
        </div>
        <div className="divider"></div>
        <div className="mic-icon-wrapper" onClick={(e) => { e.stopPropagation(); alert('Listening...'); }}>
          <Mic size={20} color={theme === 'dark' ? '#FFFFFF' : '#000000'} />
        </div>
      </div>
    </header>
  );
};
export default Header;
