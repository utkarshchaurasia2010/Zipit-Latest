import React, { useState } from 'react';
import { X, MapPin, Search, Navigation, Plus } from 'lucide-react';
import './AddressModal.css';

const AddressModal = ({ isOpen, onClose, addresses, navigate, onSelectAddress, currentRoute }) => {
  if (!isOpen) return null;

  const sortedAddresses = [...addresses].sort((a, b) => {
    if (a.is_default) return -1;
    if (b.is_default) return 1;
    return 0;
  });

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="address-modal-content slide-up" onClick={e => e.stopPropagation()}>
        <div className="modal-header-picker">
          <div style={{flex: 1}}>
            <h3 style={{fontSize: 16, fontWeight: 700, margin: 0, color: 'var(--color-text)'}}>Select delivery location</h3>
          </div>
          <button className="close-btn-picker" onClick={onClose}><X size={20} /></button>
        </div>
        <div className="address-list-scroll">
          <div className="picker-search-bar">
            <Search size={18} color="var(--color-text-light)" />
            <input type="text" placeholder="Search for area, street name..." className="picker-search-input" />
          </div>

          <div className="action-list picker-action-list">
            <div className="action-item" onClick={() => { onClose(); navigate('saved-addresses', { from: currentRoute || 'home', add: true }); }}>
              <Plus size={20} color="#0c831f" />
              <span style={{color: '#0c831f', fontWeight: 600}}>Add new address</span>
            </div>
          </div>

          <h4 className="section-title">Your saved addresses</h4>

          {sortedAddresses.map(addr => (
            <div key={addr.id} className="address-card" style={{marginTop: 12}}>
              <div className="address-card-content">
                <div className="address-icon-box" onClick={() => { onSelectAddress && onSelectAddress(addr.id); onClose(); }}>
                  <div className={`icon-circle ${addr.is_default ? 'default-active' : ''}`}>
                    <MapPin size={20} color={addr.is_default ? "#FFF" : "#333"} />
                  </div>
                </div>
                <div className="address-info-box" onClick={() => { onSelectAddress && onSelectAddress(addr.id); onClose(); }}>
                  <div className="address-header">
                    <h4 style={{margin:0}}>{addr.type}</h4>
                  </div>
                  <p className="address-details" style={{margin: '4px 0'}}>{addr.details}</p>
                  <p className="address-phone" style={{margin: 0}}>Phone number: <strong>{addr.phone || '9651568829'}</strong></p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default AddressModal;
