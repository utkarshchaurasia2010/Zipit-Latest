import React, { useState } from 'react';
import { ArrowLeft, MapPin, Trash2, Edit2, MoreHorizontal, Share, Plus, X } from 'lucide-react';
import { db } from '../services/db';
import './SavedAddressesPage.css';

const SavedAddressesPage = ({ navigate, addresses, setAddresses, from, add }) => {
  const [isEditing, setIsEditing] = useState(null);
  const [formData, setFormData] = useState({ type: 'Home', details: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const [showMenu, setShowMenu] = useState(null);
  const [isAddingNew, setIsAddingNew] = useState(!!add);

  const handleSave = async () => {
    setLoading(true);
    if (isEditing) {
      await db.addresses.update(isEditing, formData);
    } else {
      await db.addresses.add(formData);
    }
    const refreshed = await db.addresses.getAll();
    setAddresses(refreshed);
    setIsEditing(null);
    setIsAddingNew(false);
    setFormData({ type: 'Home', details: '', phone: '' });
    setLoading(false);
  };

  const handleDelete = async (id) => {
    setLoading(true);
    await db.addresses.delete(id);
    const refreshed = await db.addresses.getAll();
    setAddresses(refreshed);
    setLoading(false);
  };

  const handleSetDefault = async (id) => {
    setLoading(true);
    await db.addresses.setDefault(id);
    const refreshed = await db.addresses.getAll();
    setAddresses(refreshed);
    setLoading(false);
  };

  const handleShare = (addr) => {
    const text = `${addr.type}\n${addr.details}`;
    if (navigator.share) {
      navigator.share({ title: 'My Address', text });
    } else {
      navigator.clipboard.writeText(text);
      alert('Address copied to clipboard!');
    }
  };

  const sortedAddresses = [...addresses].sort((a, b) => {
    if (a.is_default) return -1;
    if (b.is_default) return 1;
    return 0;
  });

  return (
    <div className="addresses-page">
      <header className="page-header">
        <button className="back-btn" onClick={() => navigate(from || 'profile')}><ArrowLeft size={24} color="var(--color-text)" /></button>
        <h2>Saved Addresses</h2>
      </header>
      
      <div className="addresses-container">
        {loading && <div style={{textAlign:'center', fontSize: 12}}>Syncing...</div>}
        
        {!isAddingNew && !isEditing && (
          <div className="action-list">
            <div className="action-item" onClick={() => setIsAddingNew(true)}>
              <Plus size={20} color="#0c831f" />
              <span style={{color: '#0c831f', fontWeight: 600}}>Add new address</span>
              <ArrowLeft size={16} className="forward-arrow" color="var(--color-text-light)" />
            </div>
          </div>
        )}

        {(!isAddingNew && !isEditing) && <h4 className="section-title">Your saved addresses</h4>}

        {(!isAddingNew && !isEditing) && sortedAddresses.map(addr => (
          <div key={addr.id} className="address-card">
            <div className="address-card-content">
              <div className="address-icon-box" onClick={() => handleSetDefault(addr.id)}>
                <div className={`icon-circle ${addr.is_default ? 'default-active' : ''}`}>
                  <MapPin size={20} color={addr.is_default ? "#FFF" : "#333"} />
                </div>
              </div>
              <div className="address-info-box">
                <div className="address-header">
                  <h4 onClick={() => handleSetDefault(addr.id)}>{addr.type}</h4>
                  <MapPin size={16} className="pin-icon" />
                </div>
                <p className="address-details" onClick={() => handleSetDefault(addr.id)}>{addr.details}</p>
                <p className="address-phone">Phone number: <strong>{addr.phone || '9651568829'}</strong></p>
                
                <div className="address-actions-row">
                  <div className="action-icon-btn" onClick={() => setShowMenu(showMenu === addr.id ? null : addr.id)}>
                    <MoreHorizontal size={18} />
                  </div>
                  <div className="action-icon-btn" onClick={() => handleShare(addr)}>
                    <Share size={18} />
                  </div>
                  
                  {showMenu === addr.id && (
                    <div className="address-menu-popup">
                      <button onClick={() => { setIsEditing(addr.id); setFormData({ type: addr.type, details: addr.details, phone: addr.phone || '' }); setShowMenu(null); }}>
                        Edit
                      </button>
                      <button onClick={() => { handleDelete(addr.id); setShowMenu(null); }} style={{color: 'var(--color-danger)'}}>
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {(isEditing || isAddingNew) && (
          <div className="new-address-form">
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <h3>{isEditing ? 'Edit Address' : 'Add New Address'}</h3>
              <X size={20} onClick={() => { setIsEditing(null); setIsAddingNew(false); }} style={{cursor: 'pointer'}} />
            </div>
            <select value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})}>
              <option>Home</option>
              <option>Work</option>
              <option>Other</option>
            </select>
            <textarea 
              placeholder="Enter full address" 
              value={formData.details} 
              onChange={e => setFormData({...formData, details: e.target.value})}
              rows={3}
            />
            <input 
              type="text" 
              placeholder="Phone Number (optional)" 
              value={formData.phone || ''} 
              onChange={e => setFormData({...formData, phone: e.target.value})}
              style={{
                padding: '12px',
                border: '1px solid var(--color-border)',
                borderRadius: 'var(--radius-sm)',
                fontFamily: 'inherit',
                fontSize: '14px',
                outline: 'none',
                background: 'transparent',
                color: 'var(--color-text)'
              }}
            />
            <button className="btn-primary" onClick={handleSave} disabled={!formData.details || loading}>
              {loading ? 'Saving...' : 'Save Address'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
export default SavedAddressesPage;
