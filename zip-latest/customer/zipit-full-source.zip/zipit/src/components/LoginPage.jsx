import React, { useState } from 'react';
import './LoginPage.css';
import { db, supabase } from '../services/db';
import { Mail, ChevronRight, User, Phone, Edit2 } from 'lucide-react';

// Some sample product images for the background grid
const BACKGROUND_PRODUCTS = [
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/assets/products/sliding_images/jpeg/1c0db977-31ab-4d8e-abf3-d42e4a4b4632.jpg?ts=1706182142",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/16126a.jpg?ts=1690815413",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/51965a.jpg",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/16082a.jpg?ts=1697274092",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/10892a.jpg",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/478716a.jpg",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/10046a.jpg?ts=1690813959",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/358826a.jpg?ts=1690814980",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/14815a.jpg",
  "https://cdn.grofers.com/cdn-cgi/image/f=auto,fit=scale-down,q=70,metadata=none,w=270/app/images/products/sliding_image/373656a.jpg",
];

const LoginPage = ({ onLogin }) => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', photo: '' });

  const handleSendOtp = async (e) => {
    e.preventDefault();
    if (email.includes('@')) {
      setLoading(true);
      const { error } = await supabase.auth.signInWithOtp({ email });
      if (error) {
        alert("Error sending OTP: " + error.message);
      } else {
        setStep(2);
      }
      setLoading(false);
    }
  };

  const handleVerify = async (e) => {
    e.preventDefault();
    if (otp.length === 6) {
      setLoading(true);
      const { error } = await supabase.auth.verifyOtp({ email, token: otp, type: 'email' });
      if (error) {
        alert("Invalid OTP: " + error.message);
      } else {
        onLogin();
      }
      setLoading(false);
    }
  };

  return (
    <div className="blinkit-login-page">
      <div className="login-background">
        <div className="product-grid-bg">
          <div className="grid-scroll-container">
            {BACKGROUND_PRODUCTS.map((src, idx) => (
              <div key={idx} className="bg-product-card">
                <img src={src} alt="" />
              </div>
            ))}
            {BACKGROUND_PRODUCTS.map((src, idx) => (
              <div key={`dup-${idx}`} className="bg-product-card">
                <img src={src} alt="" />
              </div>
            ))}
            {BACKGROUND_PRODUCTS.map((src, idx) => (
              <div key={`dup2-${idx}`} className="bg-product-card">
                <img src={src} alt="" />
              </div>
            ))}
          </div>
        </div>
        <div className="fade-overlay"></div>
      </div>

      <div className="login-content">
        <div className="logo-box">
          <div className="logo-square">
            <span className="logo-text">zipit</span>
          </div>
        </div>

        <h1 className="main-title">India's last minute app</h1>
        
        {step === 1 ? (
          <>
            <p className="sub-title">Log In or Sign Up</p>
            <form onSubmit={handleSendOtp} className="login-form">
              <div className="modern-input-group">
                <div className="email-prefix">
                  <Mail size={18} color="#FFF" />
                </div>
                <input 
                  type="email" 
                  placeholder="Enter email address" 
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  autoFocus
                  disabled={loading}
                />
              </div>
              
              <button 
                type="submit" 
                className="modern-continue-btn" 
                disabled={!email.includes('@') || loading}
              >
                {loading ? 'Sending OTP...' : 'Continue'}
              </button>
            </form>
          </>
        ) : (
          <>
            <p className="sub-title">OTP sent to {email}</p>
            <form onSubmit={handleVerify} className="login-form">
              <div className="modern-input-group">
                <input 
                  type="text" 
                  placeholder="Enter 6-digit OTP" 
                  maxLength={6}
                  value={otp}
                  onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}
                  autoFocus
                  disabled={loading}
                  style={{ textAlign: 'center', letterSpacing: '4px', fontSize: '18px' }}
                />
              </div>
              
              <button 
                type="submit" 
                className="modern-continue-btn" 
                disabled={otp.length < 6 || loading}
              >
                {loading ? 'Verifying...' : 'Verify OTP'}
              </button>
            </form>
          </>
        )}
      </div>

      <div className="login-footer">
        By continuing, you agree to our <span>Terms of service</span> & <span>Privacy policy</span>
      </div>
    </div>
  );
};

export default LoginPage;
