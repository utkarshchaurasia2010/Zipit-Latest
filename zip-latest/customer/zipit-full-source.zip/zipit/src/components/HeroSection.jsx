import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import './HeroSection.css';

const HeroSection = ({ onImageChange, cart, updateCartQty, navigate }) => {
  const [carouselProducts, setCarouselProducts] = useState([]);

  useEffect(() => {
    const fetchBannersAndProducts = async () => {
      const data = await db.carousel.getAll();
      if (data.length > 0 && onImageChange) {
        // Send the first banner image URL up to App.jsx to be the unified background
        onImageChange(data[0].image_url || data[0].bg_color);
      }
      
      const allProducts = await db.products.getAll();
      const specials = allProducts.filter(p => p.is_carousel);
      setCarouselProducts(specials);
    };
    fetchBannersAndProducts();
  }, [onImageChange]);

  if (carouselProducts.length === 0) return null;

  return (
    <div className="hero-section-wrapper">
      <div className="hero-products-container">
        {carouselProducts.slice(0, 4).map(prod => {
          return (
            <div key={prod.id} className="hero-product-card" onClick={() => navigate && navigate('product-list', { categoryId: prod.category_id, category: prod.categories?.name || 'Category', from: 'home' })}>
              <div className="hero-prod-title">{prod.categories?.name || 'Category'}</div>
              <div className="hero-prod-img-container">
                <img src={prod.image_url} alt={prod.name} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HeroSection;
