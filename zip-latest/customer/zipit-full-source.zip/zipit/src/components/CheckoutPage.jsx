import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, MapPin, ChevronRight } from 'lucide-react';
import { db } from '../services/db';
import { getCartDeliveryTime, getProductDeliveryTime } from '../utils/time';
import './CheckoutPage.css';
import './ProductListPage.css'; // For the bestseller-card style

const CheckoutPage = ({ navigate, cart, updateCartQty, itemTotal, smallCartCharge, deliveryCharge, grandTotal, address, onAddressClick }) => {
  const [suggestedProducts, setSuggestedProducts] = useState([]);

  useEffect(() => {
    const fetchSuggested = async () => {
      const allProducts = await db.products.getAll();
      const cartIds = cart.map(c => c.id);
      
      // Filter out products already in the cart
      const available = allProducts.filter(p => !cartIds.includes(p.id));
      
      // Shuffle array
      for (let i = available.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [available[i], available[j]] = [available[j], available[i]];
      }
      
      // Select 10
      setSuggestedProducts(available.slice(0, 10));
    };
    
    fetchSuggested();
  }, [cart]);

  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);

  // If cart is completely empty, it shouldn't really happen here (user wouldn't be able to reach it), 
  // but if they remove the last item on this page, we can route back.
  useEffect(() => {
    if (cart.length === 0) {
      navigate('home');
    }
  }, [cart, navigate]);

  if (cart.length === 0) return null;

  return (
    <div className="checkout-page">
      <header className="checkout-header">
        <button className="back-btn" onClick={() => navigate('home')}>
          <ArrowLeft size={24} color="var(--color-text)" />
        </button>
        <h1>Checkout</h1>
      </header>

      <section className="checkout-section delivery-time-card">
        <div className="delivery-time-icon">
          <Clock size={20} color="#2F881D" />
        </div>
        <div className="delivery-time-info">
          <h2>Delivery in {getCartDeliveryTime(cart)} minutes</h2>
          <p>Shipment of {totalItems} item{totalItems > 1 ? 's' : ''}</p>
        </div>
      </section>

      <section className="checkout-section">
        <div className="checkout-cart-list">
          {cart.map(item => (
            <div key={item.id} className="checkout-cart-item">
              <div className="checkout-item-img">
                <img src={item.image_url} alt={item.name} />
              </div>
              <div className="checkout-item-info">
                <h3 className="checkout-item-name">{item.name}</h3>
                <div className="checkout-item-amount">{item.amount}</div>
                <div className="checkout-item-price-row">
                  <div className="checkout-item-price">₹{item.price}</div>
                  <div className="checkout-qty-control">
                    <button onClick={() => updateCartQty(item, -1)}>-</button>
                    <span>{item.qty}</span>
                    <button onClick={() => updateCartQty(item, 1)}>+</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {suggestedProducts.length > 0 && (
        <section className="checkout-section suggested-section">
          <h2>You might also like</h2>
          <div className="suggested-list">
            {suggestedProducts.map(prod => {
              const qty = cart.find(c => c.id === prod.id)?.qty || 0;
              return (
                <div key={prod.id} className="bestseller-card">
                  <div className="bestseller-img" style={{cursor: 'pointer'}} onClick={() => navigate('product-list', { categoryId: prod.category_id, category: prod.categories?.name, from: 'checkout' })}>
                    {prod.sticker && <div className="product-sticker">{prod.sticker}</div>}
                    <img src={prod.image_url} alt={prod.name} />
                    {qty === 0 ? (
                      <button className="add-btn-small" onClick={(e) => { e.stopPropagation(); updateCartQty(prod, 1); }}>ADD</button>
                    ) : (
                      <div className="qty-control" onClick={(e) => e.stopPropagation()}>
                        <button onClick={(e) => { e.stopPropagation(); updateCartQty(prod, -1); }}>-</button>
                        <span>{qty}</span>
                        <button onClick={(e) => { e.stopPropagation(); updateCartQty(prod, 1); }}>+</button>
                      </div>
                    )}
                  </div>
                  <div className="bestseller-info">
                    <h3 className="item-name">{prod.name}</h3>
                    <div className="item-amount" style={{fontSize: 12, color: '#666', marginBottom: 4}}>{prod.amount}</div>
                    <div className="time-tag">⏱ {getProductDeliveryTime(prod.name)} MINS</div>
                    <div className="item-price">₹{prod.price}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      <section className="checkout-section bill-summary-section">
        <h2>Bill Details</h2>
        <div className="bill-row">
          <span>Item Total</span>
          <span>₹{itemTotal}</span>
        </div>
        <div className="bill-row">
          <span>Delivery Charge</span>
          <span>{deliveryCharge === 0 ? <span style={{color: '#2F881D', fontWeight: 600}}>FREE</span> : `₹${deliveryCharge}`}</span>
        </div>
        {smallCartCharge > 0 && (
          <div className="bill-row">
            <span>Small Cart Charge</span>
            <span>₹{smallCartCharge}</span>
          </div>
        )}
        <div className="bill-row grand-total-row">
          <span>Grand Total</span>
          <span>₹{grandTotal}</span>
        </div>
      </section>

      <div className="checkout-bottom-bar">
        <div className="checkout-address-area" onClick={onAddressClick}>
          <div className="address-icon-bg">
            <MapPin size={18} />
          </div>
          <div className="checkout-address-text">
            <h3 className="checkout-address-title">
              Delivering to <strong>{address ? (address.type || 'Address') : 'Select Address'}</strong>
            </h3>
            <p className="checkout-address-detail">
              {address ? `${address.details} ${address.phone ? `• ${address.phone}` : ''}` : 'Tap to add your location'}
            </p>
          </div>
          <button className="address-change-btn">Change</button>
        </div>

        <button className="checkout-place-order-btn" onClick={() => navigate('payment', { address })}>
          <div className="checkout-btn-left">
            <span className="checkout-btn-total">₹{grandTotal}</span>
            <span className="checkout-btn-sub">Total</span>
          </div>
          <div className="checkout-btn-right">
            Place Order <ChevronRight size={20} />
          </div>
        </button>
      </div>
    </div>
  );
};

export default CheckoutPage;
