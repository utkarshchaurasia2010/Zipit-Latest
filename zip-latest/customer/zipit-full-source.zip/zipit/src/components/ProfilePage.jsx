import React, { useState } from 'react';
import './ProfilePage.css';
import { LogOut, ChevronRight, MapPin, CreditCard, ArrowLeft, Edit2, Shield, Moon, Sun } from 'lucide-react';
import { db, supabase } from '../services/db';
import { useTheme } from '../context/ThemeContext';

const ProfilePage = ({ navigate, userProfile, setUserProfile, onLogout }) => {
  const { theme, toggleTheme } = useTheme();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(userProfile || { name: 'New User', phone: '', email: '', photo: 'NU' });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const updated = await db.user.update(formData);
    if(updated) {
      setUserProfile(updated);
      setIsEditing(false);
    }
    setSaving(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  return (
    <div className={`profile-page ${theme === 'dark' ? 'dark-gradient' : 'light-gradient'}`}>
      <header className="page-header transparent">
        <button className="back-btn" onClick={() => navigate('home')}><ArrowLeft size={24} color="var(--color-text)" /></button>
      </header>
      
      <div className="profile-header-card transparent">
        {isEditing ? (
          <div className="profile-edit-form">
            <h3 style={{color: 'var(--color-text)', marginBottom: 12}}>Edit Profile Details</h3>
            <input type="text" value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Name" />
            <input type="text" value={formData.phone || ''} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="Phone (optional)" />
            <input type="email" value={formData.email || ''} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="Email Address" />
            <input type="text" value={formData.photo || ''} onChange={e => setFormData({...formData, photo: e.target.value})} placeholder="Initials (e.g. SD)" maxLength="2" />
            <div style={{display: 'flex', gap: 12, marginTop: 8}}>
              <button className="btn-secondary" onClick={() => setIsEditing(false)} style={{flex: 1, borderRadius: 12, padding: '14px 24px', fontWeight: 700, border: '1px solid var(--color-border)', background: 'transparent', color: 'var(--color-text)'}}>Cancel</button>
              <button className="btn-primary" onClick={handleSave} disabled={saving} style={{flex: 1, borderRadius: 12, padding: '14px 24px', fontWeight: 700, border: 'none', backgroundColor: 'var(--color-primary)', color: '#FFF'}}>{saving ? 'Saving...' : 'Save'}</button>
            </div>
          </div>
        ) : (
          <div className="profile-info-centered">
            <div className="profile-pic-large-wrapper">
              <div className="profile-pic-large">{userProfile?.photo || '?'}</div>
            </div>
            <h3>{userProfile?.name || 'Guest'}</h3>
            <p className="profile-contact">
              {userProfile?.phone || 'No phone'} • {userProfile?.email || 'No email'}
            </p>
            <button className="edit-profile-btn-solid" onClick={() => setIsEditing(true)}>
              Edit Profile Details
            </button>
          </div>
        )}
      </div>

      {!isEditing && (
        <div className="profile-menu">
          {userProfile?.is_admin && (
            <div className="menu-item" onClick={() => navigate('admin')}>
              <div className="menu-item-left">
                <Shield size={20} color="#0c831f" />
                <span style={{fontWeight: 600, color: '#0c831f'}}>Admin Dashboard</span>
              </div>
              <ChevronRight size={20} color="var(--color-text-light)" />
            </div>
          )}
          
          <div className="menu-item" onClick={toggleTheme}>
            <div className="menu-item-left">
              {theme === 'dark' ? <Sun size={20} color="var(--color-text)" /> : <Moon size={20} color="var(--color-text)" />}
              <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
            </div>
            <div className="theme-toggle">
              <div className={`toggle-switch ${theme === 'dark' ? 'on' : 'off'}`}></div>
            </div>
          </div>

          <div className="menu-item" onClick={() => navigate('saved-addresses', { from: 'profile' })}>
            <div className="menu-item-left">
              <MapPin size={20} color="var(--color-text)" />
              <span>Saved Addresses</span>
            </div>
            <ChevronRight size={20} color="var(--color-text-light)" />
          </div>
          <div className="menu-item" onClick={() => navigate('payment-methods')}>
            <div className="menu-item-left">
              <CreditCard size={20} color="var(--color-text)" />
              <span>Payment Methods</span>
            </div>
            <ChevronRight size={20} color="var(--color-text-light)" />
          </div>
          
          <div className="menu-item logout-btn" onClick={handleLogout}>
            <div className="menu-item-left">
              <LogOut size={20} color="var(--color-danger)" />
              <span style={{color: 'var(--color-danger)'}}>Log Out</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default ProfilePage;
