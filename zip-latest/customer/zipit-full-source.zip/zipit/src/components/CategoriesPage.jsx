import React, { useState, useEffect } from 'react';
import { db } from '../services/db';
import './CategoriesPage.css';

const CategoriesPage = ({ navigate }) => {
  const [sections, setSections] = useState([]);
  
  useEffect(() => {
    const fetchCats = async () => {
      const data = await db.categories.getAll();
      
      // Group by section
      const grouped = data.reduce((acc, cat) => {
        if (!acc[cat.section]) acc[cat.section] = [];
        acc[cat.section].push(cat);
        return acc;
      }, {});
      
      const structuredSections = Object.keys(grouped).map(sectionTitle => ({
        title: sectionTitle,
        items: grouped[sectionTitle]
      }));
      
      setSections(structuredSections);
    };
    fetchCats();
  }, []);

  return (
    <div className="categories-page-container">
      <div className="categories-scroll-area">
      {sections.map((section, idx) => (
        <div key={idx} className="category-section">
          <h3 className="category-section-title">{section.title}</h3>
          <div className="category-horizontal-scroll">
            <div className="category-grid-layout">
              {section.items.map((item, i) => (
                <div key={item.id || i} className="category-card" onClick={() => navigate('product-list', { category: item.name, categoryId: item.id, from: 'categories' })}>
                  <div className="category-card-img-wrap">
                    <img src={item.image_url} alt={item.name} />
                  </div>
                  <span className="category-card-name">{item.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
      </div>
    </div>
  );
};
export default CategoriesPage;
