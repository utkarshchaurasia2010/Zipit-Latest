import React, { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { db } from '../services/db';
import { getProductDeliveryTime } from '../utils/time';
import './ProductListPage.css';

const ProductListPage = ({ category, categoryId, navigate, cart, updateCartQty, from }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      if (categoryId) {
        const data = await db.products.getByCategory(categoryId);
        setProducts(data);
      } else {
        setProducts([]);
      }
      setLoading(false);
    };
    fetchProducts();
  }, [categoryId]);

  const getQty = (id) => {
    const item = cart.find(c => c.id === id);
    return item ? item.qty : 0;
  };

  return (
    <div className="product-list-page">
      <header className="page-header">
        <button className="back-btn" onClick={() => navigate(from || 'home')}><ArrowLeft size={24} color="var(--color-text)" /></button>
        <h3 style={{margin: 0, fontSize: 16}}>{category}</h3>
      </header>
      
      {loading ? (
        <div style={{textAlign: 'center', padding: 40}}>Loading products...</div>
      ) : products.length === 0 ? (
        <div style={{textAlign: 'center', padding: 40, color: '#666'}}>No products found in this category.</div>
      ) : (
        <div className="product-list-grid">
          {products.map(item => {
            const qty = getQty(item.id);
            return (
              <div key={item.id} className="bestseller-card stagger-item">
                <div className="bestseller-img">
                  {item.sticker && <div className="product-sticker">{item.sticker}</div>}
                  <img src={item.image_url} alt={item.name} />
                  {qty === 0 ? (
                    <button className="add-btn-small" onClick={() => updateCartQty(item, 1)}>ADD</button>
                  ) : (
                    <div className="qty-control">
                      <button onClick={() => updateCartQty(item, -1)}>-</button>
                      <span>{qty}</span>
                      <button onClick={() => updateCartQty(item, 1)}>+</button>
                    </div>
                  )}
                </div>
                <div className="bestseller-info">
                  <h3 className="item-name">{item.name}</h3>
                  <div className="item-amount" style={{fontSize: 12, color: '#666', marginBottom: 4}}>{item.amount}</div>
                  <div className="time-tag">⏱ {getProductDeliveryTime(item.name)} MINS</div>
                  <div className="item-price">₹{item.price}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
export default ProductListPage;
