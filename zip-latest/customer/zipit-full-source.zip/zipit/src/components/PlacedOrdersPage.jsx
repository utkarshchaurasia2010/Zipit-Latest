import React, { useState, useEffect } from 'react';
import { PackageCheck, ShoppingBag } from 'lucide-react';
import { db } from '../services/db';
import './HistoryPage.css';

const PlacedOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const data = await db.orders.getAll();
        setOrders(data || []);
      } catch (err) {
        setError(err.message);
      }
      setLoading(false);
    };
    fetchOrders();
  }, []);

  if (loading) {
    return <div style={{flex:1, display:'flex', justifyContent:'center', alignItems:'center'}}>Loading orders...</div>;
  }

  return (
    <div className="history-page">
      <header className="page-header">
        <h2>Your Orders</h2>
      </header>
      <div className="orders-list">
        {error && <div style={{color:'red', padding: 20}}>Error: Did you run the SQL script? {error}</div>}
        {orders.length === 0 && !error ? (
          <div style={{textAlign: 'center', padding: '40px 20px', color: 'var(--color-text-light)'}}>
            <ShoppingBag size={48} style={{opacity: 0.2, marginBottom: 16}} />
            <p>No orders placed yet.</p>
          </div>
        ) : (
          <>
            {orders.filter(o => o.status !== 'Delivered').length > 0 && (
              <div className="orders-section">
                <h3 className="section-title">Active Orders</h3>
                {orders.filter(o => o.status !== 'Delivered').map(order => (
                  <div key={order.id} className="order-card active-order-card">
                    <div className="order-card-header">
                      <div className="order-status active-status">
                        <PackageCheck size={16} color="#0c831f" />
                        <span className="status-text">{order.status}</span>
                      </div>
                      <span className="order-date">{new Date(order.created_at).toLocaleString()}</span>
                    </div>
                    <div className="order-details">
                      <div style={{display: 'flex', justifyContent: 'space-between'}}>
                        <p className="order-items" style={{fontWeight: 700}}>Order ID: {order.id.split('-')[0]}</p>
                        <h4 className="order-amount">₹{order.total}</h4>
                      </div>
                      <div style={{marginTop: 8}}>
                        {order.items.map(item => (
                          <div key={item.id} style={{fontSize: 13, color: 'var(--color-text-light)'}}>
                            {item.qty}x {item.name}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="order-footer">
                      <span style={{fontSize: 12, color: 'var(--color-text-light)', marginTop: 8}}>
                        Paid via {order.payment_method}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {orders.filter(o => o.status === 'Delivered').length > 0 && (
              <div className="orders-section" style={{marginTop: 24}}>
                <h3 className="section-title" style={{fontSize: 14, color: 'var(--color-text-light)'}}>Past Orders</h3>
                {orders.filter(o => o.status === 'Delivered').map(order => (
                  <div key={order.id} className="order-card past-order-card">
                    <div className="order-card-header">
                      <div className="order-status">
                        <PackageCheck size={16} color="var(--color-text-light)" />
                        <span className="status-text" style={{color: 'var(--color-text-light)'}}>{order.status}</span>
                      </div>
                      <span className="order-date">{new Date(order.created_at).toLocaleDateString()}</span>
                    </div>
                    <div className="order-details">
                      <div style={{display: 'flex', justifyContent: 'space-between'}}>
                        <p className="order-items" style={{fontWeight: 700}}>Order ID: {order.id.split('-')[0]}</p>
                        <h4 className="order-amount">₹{order.total}</h4>
                      </div>
                      <div style={{marginTop: 8}}>
                        {order.items.map(item => (
                          <div key={item.id} style={{fontSize: 13, color: 'var(--color-text-light)'}}>
                            {item.qty}x {item.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
export default PlacedOrdersPage;
