import React, { useState, useEffect, useRef } from 'react';
import { db } from '../services/db';
import { ArrowLeft, Plus, Edit2, Trash2, Upload } from 'lucide-react';
import './AdminDashboard.css';

const AdminDashboard = ({ navigate }) => {
  const [activeTab, setActiveTab] = useState('categories'); // 'categories' | 'products' | 'orders'
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [banners, setBanners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({});
  const [imageFile, setImageFile] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const fileInputRef = useRef(null);

  const sections = ['Grocery & Kitchen', 'Snacks & Drinks', 'Household Essentials'];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const userProfile = await db.user.get();
    if (!userProfile?.is_admin) {
      alert("Unauthorized Access. You are not an admin.");
      navigate('home');
      return;
    }
    setProfile(userProfile);
    
    await fetchCategories();
    
    setLoading(false);
  };
  
  const fetchCategories = async () => {
    const cats = await db.categories.getAll();
    setCategories(cats);
  };
  
  const fetchProducts = async (categoryId) => {
    // For admin view, we want all products, but right now our API only has getByCategory
    // To list all products easily, we'd need a getAll for products, or we can just fetch per category.
    // Let's just fetch all by iterating over categories for simplicity since this is a prototype,
    // OR we can add a getAll to db.products.
    // For now, let's just group them in the UI. 
  };
  
  // Quick fix: Add getAll to db.products in db.js, but since I didn't, I will use a workaround or update db.js.
  // Actually, I can just fetch them all directly using supabase instance.
  // Let's do that for now to avoid editing db.js again unnecessarily.
  const loadAllProducts = async () => {
    const { supabase } = await import('../services/db');
    const { data } = await supabase.from('products').select('*, categories(name)').order('created_at', { ascending: false });
    
    const processedData = (data || []).map(p => {
      const is_carousel = p.name.includes('---TAG:CAROUSEL---');
      const is_grid = p.name.includes('---TAG:GRID---');
      const stickerMatch = p.name.match(/---STICKER:(.*?)---/);
      const sticker = stickerMatch ? stickerMatch[1] : null;
      const name = p.name.replace('---TAG:CAROUSEL---', '').replace('---TAG:GRID---', '').replace(/---STICKER:.*?---/g, '');
      return { ...p, name, is_carousel, is_grid, sticker };
    });
    setProducts(processedData);
  };
  
  const loadOrders = async () => {
    const data = await db.orders.getAllAdmin();
    setOrders(data);
  };
  
  const loadBanners = async () => {
    const data = await db.carousel.getAll();
    setBanners(data);
  };

  useEffect(() => {
    if (activeTab === 'products' || activeTab === 'grid-products') {
      loadAllProducts();
    } else if (activeTab === 'orders') {
      loadOrders();
    } else if (activeTab === 'banners') {
      loadBanners();
    } else {
      fetchCategories();
    }
  }, [activeTab]);

  const handleDelete = async (id) => {
    if (window.confirm(`Are you sure you want to delete this ${activeTab.slice(0,-1)}?`)) {
      if (activeTab === 'categories') {
        await db.categories.delete(id);
        fetchCategories();
      } else if (activeTab === 'products') {
        await db.products.delete(id);
        loadAllProducts();
      } else if (activeTab === 'banners') {
        await db.carousel.delete(id);
        loadBanners();
      } else if (activeTab === 'orders') {
        await db.orders.delete(id);
        loadOrders();
      }
    }
  };

  const openModal = (item = null) => {
    setEditingItem(item);
    if (activeTab === 'categories') {
      setFormData(item ? { name: item.name, section: item.section, image_url: item.image_url } : { name: '', section: 'Grocery & Kitchen', image_url: '' });
    } else if (activeTab === 'banners') {
      setFormData(item ? { image_url: item.image_url, link_url: item.link_url || '', bg_color: item.bg_color || '#F8CB46', order_index: item.order_index || 1 } : { image_url: '', link_url: '', bg_color: '#F8CB46', order_index: 1 });
    } else {
      setFormData(item ? { 
        name: item.name, 
        category_id: item.category_id, 
        price: item.price, 
        amount: item.amount,
        image_url: item.image_url,
        is_carousel: item.is_carousel || false,
        is_grid: item.is_grid || false,
        sticker: item.sticker || ''
      } : { 
        name: '', 
        category_id: categories.length > 0 ? categories[0].id : '', 
        price: '', 
        amount: '',
        image_url: '',
        is_carousel: false,
        is_grid: false,
        sticker: ''
      });
    }
    setImageFile(null);
    setIsModalOpen(true);
  };

  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    let imageUrl = formData.image_url;
    
    if (imageFile) {
      const uploader = activeTab === 'categories' ? db.categories.uploadImage : db.products.uploadImage;
      const uploadedUrl = await uploader(imageFile);
      if (uploadedUrl) {
        imageUrl = uploadedUrl;
      } else {
        alert("Failed to upload image.");
        setIsSubmitting(false);
        return;
      }
    }
    
    if (activeTab === 'categories') {
      const dataToSave = { name: formData.name, section: formData.section, image_url: imageUrl };
      if (editingItem) await db.categories.update(editingItem.id, dataToSave);
      else await db.categories.add(dataToSave);
      fetchCategories();
    } else if (activeTab === 'banners') {
      const dataToSave = { image_url: imageUrl, link_url: formData.link_url, bg_color: formData.bg_color, order_index: parseInt(formData.order_index) || 1 };
      if (editingItem) await db.carousel.update(editingItem.id, dataToSave);
      else await db.carousel.add(dataToSave);
      loadBanners();
    } else {
      const dataToSave = { 
        name: formData.name, 
        category_id: formData.category_id, 
        price: parseFloat(formData.price), 
        amount: formData.amount,
        image_url: imageUrl,
        is_carousel: formData.is_carousel || false,
        is_grid: formData.is_grid || false,
        sticker: formData.sticker || ''
      };
      
      if (dataToSave.is_carousel) {
        const carouselCount = products.filter(p => p.is_carousel && (!editingItem || p.id !== editingItem.id)).length;
        if (carouselCount >= 4) {
          alert("limit of carousel card is 4 , remove other products to add");
          setIsSubmitting(false);
          return;
        }
      }

      if (editingItem) await db.products.update(editingItem.id, dataToSave);
      else await db.products.add(dataToSave);
      loadAllProducts();
    }
    
    setIsModalOpen(false);
    setIsSubmitting(false);
  };

  if (loading) return <div className="admin-loading">Loading Admin Panel...</div>;

  return (
    <div className="admin-container">
      <header className="admin-header">
        <button onClick={() => navigate('profile')} className="back-btn"><ArrowLeft size={24} /></button>
        <h1>Admin Dashboard</h1>
        {activeTab !== 'grid-products' && activeTab !== 'orders' && (
          <button onClick={() => openModal()} className="add-btn"><Plus size={20} /> Add New</button>
        )}
      </header>
      
      <div className="admin-tabs">
        <button className={activeTab === 'categories' ? 'active' : ''} onClick={() => setActiveTab('categories')}>Categories</button>
        <button className={activeTab === 'products' ? 'active' : ''} onClick={() => setActiveTab('products')}>Products</button>
        <button className={activeTab === 'grid-products' ? 'active' : ''} onClick={() => setActiveTab('grid-products')}>Grid Products</button>
        <button className={activeTab === 'banners' ? 'active' : ''} onClick={() => setActiveTab('banners')}>Banners</button>
        <button className={activeTab === 'orders' ? 'active' : ''} onClick={() => setActiveTab('orders')}>Orders</button>
      </div>
      
      <div className="admin-content">
        {activeTab === 'categories' && (
          categories.length === 0 ? <p className="no-data">No categories found.</p> : (
            <div className="admin-list">
              {categories.map(cat => (
                <div key={cat.id} className="admin-list-item">
                  <img src={cat.image_url} alt={cat.name} className="admin-item-img" />
                  <div className="admin-item-info">
                    <h3>{cat.name}</h3>
                    <span>{cat.section}</span>
                  </div>
                  <div className="admin-item-actions">
                    <button onClick={() => openModal(cat)} className="edit-btn"><Edit2 size={18}/></button>
                    <button onClick={() => handleDelete(cat.id)} className="delete-btn"><Trash2 size={18}/></button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
        
        {activeTab === 'products' && (
          products.length === 0 ? <p className="no-data">No products found.</p> : (
            <div className="admin-list">
              {products.map(prod => (
                <div key={prod.id} className="admin-list-item" style={{ position: 'relative', overflow: 'hidden' }}>
                  <div style={{ position: 'relative', width: '60px', height: '60px', flexShrink: 0, marginRight: '16px', borderRadius: '8px', overflow: 'hidden' }}>
                    {prod.is_carousel && (
                      <div style={{ position: 'absolute', top: 0, left: 0, background: '#F8CB46', color: '#000', fontSize: '9px', padding: '2px 4px', borderBottomRightRadius: '8px', fontWeight: 'bold', zIndex: 4 }}>
                        CAROUSEL
                      </div>
                    )}
                    {prod.sticker && (
                      <div style={{ position: 'absolute', top: prod.is_carousel ? '14px' : '0', left: 0, background: 'linear-gradient(135deg, #FF6B6B 0%, #E83E8C 100%)', color: 'white', fontSize: '8px', fontWeight: 800, padding: '2px 4px', borderBottomRightRadius: '8px', zIndex: 3, textTransform: 'uppercase' }}>
                        {prod.sticker}
                      </div>
                    )}
                    <img src={prod.image_url} alt={prod.name} style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                  </div>
                  <div className="admin-item-info">
                    <h3>{prod.name}</h3>
                    <div className="prod-meta">
                      <span className="prod-cat">{prod.categories?.name}</span>
                      <span className="prod-price">₹{prod.price}</span>
                      <span className="prod-amt">{prod.amount}</span>
                    </div>
                  </div>
                  <div className="admin-item-actions">
                    <button onClick={() => openModal(prod)} className="edit-btn"><Edit2 size={18}/></button>
                    <button onClick={() => handleDelete(prod.id)} className="delete-btn"><Trash2 size={18}/></button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
        
        {activeTab === 'grid-products' && (
          products.length === 0 ? <p className="no-data">No products found.</p> : (
            <div className="admin-list">
              {products.map(prod => (
                <div key={prod.id} className="admin-list-item" style={{ position: 'relative', overflow: 'hidden', alignItems: 'center' }}>
                  <div style={{ position: 'relative', width: '60px', height: '60px', flexShrink: 0, marginRight: '16px', borderRadius: '8px', overflow: 'hidden' }}>
                    {prod.sticker && (
                      <div style={{ position: 'absolute', top: 0, left: 0, background: 'linear-gradient(135deg, #FF6B6B 0%, #E83E8C 100%)', color: 'white', fontSize: '8px', fontWeight: 800, padding: '2px 4px', borderBottomRightRadius: '8px', zIndex: 3, textTransform: 'uppercase' }}>
                        {prod.sticker}
                      </div>
                    )}
                    <img src={prod.image_url} alt={prod.name} style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                  </div>
                  <div className="admin-item-info">
                    <h3>{prod.name}</h3>
                    <div className="prod-meta">
                      <span className="prod-cat">{prod.categories?.name}</span>
                    </div>
                  </div>
                  <div className="admin-item-actions" style={{ flexDirection: 'row', width: 'auto' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', margin: 0 }}>
                      <input 
                        type="checkbox" 
                        checked={prod.is_grid} 
                        onChange={async (e) => {
                          const updatedState = e.target.checked;
                          // Optimistic update
                          setProducts(products.map(p => p.id === prod.id ? { ...p, is_grid: updatedState } : p));
                          await db.products.update(prod.id, { ...prod, is_grid: updatedState });
                        }} 
                        style={{ width: 18, height: 18, cursor: 'pointer' }}
                      />
                      <span style={{ fontSize: 13, fontWeight: 600 }}>List in Grid</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
        
        {activeTab === 'orders' && (
          orders.length === 0 ? <p className="no-data">No orders yet.</p> : (
            <div className="admin-list">
              {orders.map(order => (
                <div key={order.id} className="admin-list-item admin-order-card">
                  <div className="admin-order-header">
                    <h3>Order #{order.id.slice(0,8)}</h3>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <select 
                        className={`status-select ${order.status?.toLowerCase().replace(/ /g, '-')}`}
                        value={order.status || 'Preparing'}
                        onChange={async (e) => {
                          await db.orders.updateStatus(order.id, e.target.value);
                          loadOrders();
                        }}
                      >
                        <option value="Payment Pending">Payment Pending</option>
                        <option value="Preparing">Preparing</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Delivered">Delivered</option>
                      </select>
                      <button onClick={() => handleDelete(order.id)} className="delete-btn" style={{ padding: '6px 8px' }} title="Delete Order">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                  <div className="admin-order-details">
                    <p><strong>Customer:</strong> {order.profiles?.name} ({order.profiles?.phone})</p>
                    <p><strong>Total:</strong> ₹{order.total}</p>
                    <p><strong>Items:</strong> {order.items?.length} items</p>
                    <div className="admin-order-items">
                      {order.items?.map((item, i) => (
                        <span key={i} className="order-item-chip">{item.qty}x {item.name}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {activeTab === 'banners' && (
          banners.length === 0 ? <p className="no-data">No banners found.</p> : (
            <div className="admin-list">
              {banners.map(banner => (
                <div key={banner.id} className="admin-list-item">
                  <img src={banner.image_url} alt="Banner" className="admin-item-img" style={{width: 80, height: 40, objectFit: 'cover'}} />
                  <div className="admin-item-info">
                    <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
                      <div style={{width: 16, height: 16, borderRadius: '50%', backgroundColor: banner.bg_color || '#FFF', border: '1px solid #ddd'}} />
                      <h3>{banner.bg_color}</h3>
                    </div>
                    <span>Order: {banner.order_index}</span>
                  </div>
                  <div className="admin-item-actions">
                    <button onClick={() => openModal(banner)} className="edit-btn"><Edit2 size={18}/></button>
                    <button onClick={() => handleDelete(banner.id)} className="delete-btn"><Trash2 size={18}/></button>
                  </div>
                </div>
              ))}
            </div>
          )
        )}
      </div>

      {isModalOpen && (
        <div className="admin-modal-overlay">
          <div className="admin-modal">
            <h2>{editingItem ? 'Edit' : 'Add'} {activeTab === 'categories' ? 'Category' : activeTab.slice(0, -1)}</h2>
            <form onSubmit={handleSubmit}>
              {activeTab !== 'banners' && (
                <div className="form-group">
                  <label>Name</label>
                  <input 
                    type="text" 
                    value={formData.name || ''} 
                    onChange={e => setFormData({...formData, name: e.target.value})} 
                    required 
                  />
                </div>
              )}
              
              {activeTab === 'categories' ? (
                <div className="form-group">
                  <label>Section</label>
                  <select value={formData.section || ''} onChange={e => setFormData({...formData, section: e.target.value})}>
                    {sections.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              ) : activeTab === 'banners' ? (
                <div className="form-row">
                  <div className="form-group half">
                    <label>Background Color (Hex or Gradient)</label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <input type="text" value={formData.bg_color || '#F8CB46'} onChange={e => setFormData({...formData, bg_color: e.target.value})} required style={{ flex: 1 }} />
                      <div style={{ width: 40, height: 40, borderRadius: 8, background: formData.bg_color || '#F8CB46', border: '1px solid #ddd', flexShrink: 0 }} />
                    </div>
                  </div>
                  <div className="form-group half">
                    <label>Order Index</label>
                    <input type="number" value={formData.order_index || 1} onChange={e => setFormData({...formData, order_index: e.target.value})} required />
                  </div>
                </div>
              ) : (
                <>
                  <div className="form-group">
                    <label>Category</label>
                    <select value={formData.category_id || ''} onChange={e => setFormData({...formData, category_id: e.target.value})} required>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div className="form-row">
                    <div className="form-group half">
                      <label>Price (₹)</label>
                      <input type="number" value={formData.price || ''} onChange={e => setFormData({...formData, price: e.target.value})} required />
                    </div>
                    <div className="form-group half">
                      <label>Amount (e.g. 500g, 1L)</label>
                      <input type="text" value={formData.amount || ''} onChange={e => setFormData({...formData, amount: e.target.value})} required />
                    </div>
                  </div>
                  <div className="form-group" style={{display: 'flex', alignItems: 'center', gap: 8}}>
                    <input type="checkbox" id="is_carousel" checked={formData.is_carousel || false} onChange={e => setFormData({...formData, is_carousel: e.target.checked})} style={{width: 'auto', margin: 0}} />
                    <label htmlFor="is_carousel" style={{margin: 0, cursor: 'pointer'}}>Add to Carousel (Show product overlay on Home Banners)</label>
                  </div>
                  <div className="form-group">
                    <label>Sticker Text (optional)</label>
                    <input 
                      type="text" 
                      placeholder="e.g. 20% OFF, Mega Sale" 
                      value={formData.sticker || ''} 
                      onChange={e => setFormData({...formData, sticker: e.target.value})} 
                    />
                  </div>
                </>
              )}
              
              <div className="form-group">
                <label>Image</label>
                <div className="image-upload-box" onClick={() => fileInputRef.current.click()}>
                  {imageFile ? (
                    <span>{imageFile.name}</span>
                  ) : formData.image_url ? (
                    <img src={formData.image_url} alt="Current" className="preview-img" />
                  ) : (
                    <div className="upload-placeholder">
                      <Upload size={24} />
                      <span>Click to upload image</span>
                    </div>
                  )}
                </div>
                <input 
                  type="file" 
                  accept="image/*" 
                  ref={fileInputRef} 
                  style={{display: 'none'}} 
                  onChange={handleImageChange}
                  required={!editingItem && !formData.image_url}
                />
              </div>
              
              <div className="modal-actions">
                <button type="button" onClick={() => setIsModalOpen(false)} className="cancel-btn">Cancel</button>
                <button type="submit" disabled={isSubmitting} className="save-btn">
                  {isSubmitting ? 'Saving...' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
