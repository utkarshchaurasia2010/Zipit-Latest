import React, { useState, useEffect } from 'react';
import LoginPage from './components/LoginPage';
import Header from './components/Header';
import ProductGrid from './components/ProductGrid';
import CategoriesPage from './components/CategoriesPage';
import PlacedOrdersPage from './components/PlacedOrdersPage';
import ProfilePage from './components/ProfilePage';
import SavedAddressesPage from './components/SavedAddressesPage';
import PaymentMethodsPage from './components/PaymentMethodsPage';
import ProductListPage from './components/ProductListPage';
import PaymentPage from './components/PaymentPage';
import AdminDashboard from './components/AdminDashboard';
import CartBar from './components/CartBar';
import BottomNav from './components/BottomNav';
import HeroSection from './components/HeroSection';
import CheckoutPage from './components/CheckoutPage';
import AddressModal from './components/AddressModal';
import SearchOverlay from './components/SearchOverlay';
import OnboardingModal from './components/OnboardingModal';
import UpdatePrompt from './components/UpdatePrompt';
import Toast from './components/Toast';
import SkeletonLoader from './components/SkeletonLoader';
import { playNotificationSound } from './utils/audio';
import { db, supabase } from './services/db';
import './index.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [view, setView] = useState({ name: 'home', params: {} });
  const [cart, setCart] = useState([]);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [deliveryTime, setDeliveryTime] = useState(16);
  const [headerBgColor, setHeaderBgColor] = useState('linear-gradient(to right, #F8CB46, #F9D423)');

  const [userProfile, setUserProfile] = useState(null);
  const [addresses, setAddresses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitializingAuth, setIsInitializingAuth] = useState(true);
  
  const [isNavHidden, setIsNavHidden] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const lastScrollY = React.useRef(0);
  
  const [toast, setToast] = useState({ visible: false, title: '', message: '' });

  // Realtime notification listener for the user & admin
  useEffect(() => {
    if (!userProfile?.id) return;
    
    // User listener (UPDATEs to their own orders)
    const userChannel = supabase.channel('user-orders-listener')
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders', filter: `profile_id=eq.${userProfile.id}` }, (payload) => {
        const newStatus = payload.new.status;
        const oldStatus = payload.old.status;
        if (newStatus && newStatus !== oldStatus) {
          playNotificationSound();
          setToast({ visible: true, title: 'Order Update', message: `Your order status changed to: ${newStatus}` });
        }
      })
      .subscribe();
      
    // Admin listener (INSERTs to all orders)
    let adminChannel = null;
    if (userProfile.is_admin) {
      adminChannel = supabase.channel('admin-orders-listener')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, (payload) => {
          playNotificationSound();
          setToast({ visible: true, title: 'New Order Received!', message: `Order #${payload.new.id.slice(0,8)} for ₹${payload.new.total}` });
        })
        .subscribe();
    }
      
    return () => {
      supabase.removeChannel(userChannel);
      if (adminChannel) supabase.removeChannel(adminChannel);
    };
  }, [userProfile]);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setIsScrolled(currentScrollY > 150);
      
      if (currentScrollY > lastScrollY.current && currentScrollY > 50) {
        setIsNavHidden(true);
      } else if (currentScrollY < lastScrollY.current) {
        setIsNavHidden(false);
      }
      lastScrollY.current = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Initialize Auth state
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsLoggedIn(!!session);
      setIsInitializingAuth(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsLoggedIn(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch data once logged in and when app comes back to foreground
  useEffect(() => {
    if (!isLoggedIn) return;
    
    const initDB = async (silent = false) => {
      if (!silent) setIsLoading(true);
      const profile = await db.user.get();
      setUserProfile(profile);
      const addrs = await db.addresses.getAll();
      setAddresses(addrs);
      
      const savedCart = await db.carts.get();
      if (savedCart && savedCart.length > 0) setCart(savedCart);
      
      if (!silent) setIsLoading(false);

      // Precache images in background
      if (!silent) {
        setTimeout(async () => {
          if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
            const allProducts = await db.products.getAll();
            const allCarousel = await db.carousel.getAll();
            const allCategories = await db.categories.getAll();
            const urls = [
              ...allCategories.map(c => c.image_url),
              ...allProducts.map(p => p.image_url),
              ...allCarousel.map(c => c.image_url)
            ].filter(Boolean); // Filter out nulls
            
            // Remove duplicates
            const uniqueUrls = [...new Set(urls)];
            
            navigator.serviceWorker.controller.postMessage({
              type: 'PRECACHE_IMAGES',
              urls: uniqueUrls
            });
          }
        }, 1000); // Give the UI a second to render first
      }
    };
    
    initDB();

    // Re-fetch data silently when app comes back to foreground
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        initDB(true);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Listen for global data changes (products, categories)
    const dataChannel = supabase.channel('global-data-sync')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, () => initDB(true))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'categories' }, () => initDB(true))
      .subscribe();
      
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      supabase.removeChannel(dataChannel);
    };
  }, [isLoggedIn]);

  useEffect(() => {
    setDeliveryTime(Math.floor(Math.random() * 11) + 8);
  }, []);

  const navigate = (name, params = {}) => {
    setView({ name, params });
    window.scrollTo(0, 0);
  };

  const updateCartQty = (product, delta) => {
    setCart(prev => {
      let newCart = prev;
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.qty + delta <= 0) newCart = prev.filter(item => item.id !== product.id);
        else newCart = prev.map(item => item.id === product.id ? { ...item, qty: item.qty + delta } : item);
      } else {
        if (delta > 0) newCart = [...prev, { ...product, qty: 1 }];
      }
      
      if (userProfile?.id) {
        db.carts.sync(newCart);
      }
      return newCart;
    });
  };

  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  const itemTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const smallCartCharge = (itemTotal > 0 && itemTotal < 69) ? 11 : 0;
  const deliveryCharge = (itemTotal > 0 && itemTotal < 149) ? 25 : 0;
  const grandTotal = itemTotal > 0 ? itemTotal + smallCartCharge + deliveryCharge : 0;

  if (isInitializingAuth) {
    return <SkeletonLoader />;
  }

  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  if (isLoading) {
    return <SkeletonLoader />;
  }

  const showBottomNav = ['home', 'categories', 'orders'].includes(view.name);
  const showCartBar = totalItems > 0 && view.name !== 'checkout-summary' && view.name !== 'payment' && view.name !== 'checkout-address' && view.name !== 'checkout';

  const defaultAddress = addresses.find(a => a.is_default) || addresses[0];

  const renderView = () => {
    switch (view.name) {
      case 'home':
      case 'categories':
        const isImage = headerBgColor?.startsWith('http') || headerBgColor?.startsWith('url(') || headerBgColor?.startsWith('data:image');
        const heroStyle = {
          ...(isImage 
              ? { backgroundImage: headerBgColor.startsWith('http') || headerBgColor.startsWith('data:') ? `url(${headerBgColor})` : headerBgColor, backgroundSize: 'cover', backgroundPosition: 'top center' } 
              : { backgroundColor: headerBgColor }),
          transition: 'background 0.5s ease',
          marginTop: '-186px',
          paddingTop: '186px',
          paddingBottom: view.name === 'home' ? '0px' : '16px'
        };

        let headerBg = 'transparent';
        if (view.name !== 'home') {
          headerBg = 'var(--color-header-bg)';
        } else if (isScrolled) {
          headerBg = 'var(--color-header-bg)';
        }

        return (
          <>
            <Header 
              time={deliveryTime} 
              onAddressClick={() => setIsAddressModalOpen(true)}
              onSearchClick={() => setIsSearchOpen(true)}
              onProfileClick={() => navigate('profile')}
              defaultAddress={defaultAddress}
              isHome={view.name === 'home'}
              isNavHidden={isNavHidden}
              bgColor={headerBg}
              cart={cart}
            />
            {view.name === 'home' && (
              <div className="home-hero-wrapper" style={heroStyle}>
                <HeroSection onImageChange={setHeaderBgColor} cart={cart} updateCartQty={updateCartQty} navigate={navigate} />
              </div>
            )}
            
            {view.name === 'home' ? (
              <ProductGrid cart={cart} updateCartQty={updateCartQty} navigate={navigate} />
            ) : (
              <CategoriesPage navigate={navigate} />
            )}
          </>
        );
      case 'orders':
        return <PlacedOrdersPage />;
      case 'profile':
        return <ProfilePage navigate={navigate} userProfile={userProfile} setUserProfile={setUserProfile} onLogout={() => { setIsLoggedIn(false); setCart([]); setUserProfile(null); }} />;
      case 'saved-addresses':
        return <SavedAddressesPage navigate={navigate} addresses={addresses} setAddresses={setAddresses} from={view.params.from} add={view.params.add} />;
      case 'payment-methods':
        return <PaymentMethodsPage navigate={navigate} />;
      case 'product-list':
        return <ProductListPage category={view.params.category} categoryId={view.params.categoryId} navigate={navigate} cart={cart} updateCartQty={updateCartQty} from={view.params.from} />;
      case 'checkout':
        return <CheckoutPage navigate={navigate} cart={cart} updateCartQty={updateCartQty} itemTotal={itemTotal} smallCartCharge={smallCartCharge} deliveryCharge={deliveryCharge} grandTotal={grandTotal} address={defaultAddress} onAddressClick={() => setIsAddressModalOpen(true)} />;
      case 'payment':
        return <PaymentPage navigate={navigate} cart={cart} total={grandTotal} deliveryCharge={deliveryCharge} smallCartCharge={smallCartCharge} address={view.params.address} clearCart={() => setCart([])} />;
      case 'admin':
        return <AdminDashboard navigate={navigate} />;
      default:
        return null;
    }
  };

  const handleSetDefaultAddress = async (id) => {
    await db.addresses.setDefault(id);
    const addrs = await db.addresses.getAll();
    setAddresses(addrs);
  };

  return (
    <>
      <div key={view.name} className="page-fade-in" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {renderView()}
      </div>
      
      {showCartBar && (
        <CartBar count={totalItems} total={itemTotal} cart={cart} onOpen={() => navigate('checkout')} isNavHidden={!showBottomNav || isNavHidden} />
      )}
      
      {showBottomNav && (
        <BottomNav activeTab={view.name} navigate={navigate} openCart={() => navigate('checkout')} isNavHidden={isNavHidden} />
      )}
      
      <AddressModal 
        isOpen={isAddressModalOpen} 
        onClose={() => setIsAddressModalOpen(false)} 
        addresses={addresses}
        navigate={navigate}
        onSelectAddress={handleSetDefaultAddress}
        currentRoute={view.name}
      />
      <SearchOverlay 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
        cart={cart}
        updateCartQty={updateCartQty}
      />
      
      {userProfile?.name === 'New User' && (
        <OnboardingModal 
          userProfile={userProfile} 
          onComplete={(newData) => {
            setUserProfile(prev => ({ ...prev, ...newData }));
          }} 
        />
      )}
      
      <Toast 
        visible={toast.visible} 
        title={toast.title} 
        message={toast.message} 
        onClose={() => setToast({ ...toast, visible: false })} 
      />
      <UpdatePrompt />
    </>
  );
}

export default App;
