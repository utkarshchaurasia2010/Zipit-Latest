import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://bbaggauqnlcohrgvsios.supabase.co';
const supabaseAnonKey = 'sb_publishable_rCjAUoKGrW0u-CCnBb9rQw_ori9Y1dQ';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

const getUserId = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return session?.user?.id;
};

export const db = {
  user: {
    get: async () => {
      const pid = await getUserId();
      if (!pid) return null;
      
      const { data, error } = await supabase.from('profiles').select('*').eq('id', pid).single();
      
      if (!data) {
        // Use a random phone to avoid UNIQUE constraint errors if multiple test accounts are made
        const randomPhone = 'temp_' + Math.floor(Math.random() * 10000);
        const { data: newData, error: insertError } = await supabase.from('profiles').insert([{ 
          id: pid,
          name: 'New User', 
          phone: randomPhone, 
          email: '',
          photo: 'NU' 
        }]).select().single();
        if (insertError) console.error("DB Error (profiles insert):", insertError);
        return newData;
      }
      return data;
    },
    update: async (formData) => {
      const pid = await getUserId();
      if (!pid) return null;
      
      const { id, ...updateData } = formData;
      
      // Convert empty strings to null so Postgres doesn't throw a duplicate constraint error 
      // when multiple users have an empty phone number.
      if (updateData.phone === '') {
        updateData.phone = null;
      }
      
      // If email is empty, we remove it from the update payload to avoid crashing
      // if the 'email' column does not exist yet.
      if (updateData.email === '') {
        delete updateData.email;
      }

      const { data, error } = await supabase.from('profiles').update(updateData).eq('id', pid).select().single();
      if (error) {
        console.error("DB Error (profiles update):", error);
        alert("Database Error: " + error.message);
      }
      return data;
    }
  },
  addresses: {
    getAll: async () => {
      const pid = await getUserId();
      if (!pid) return [];
      const { data, error } = await supabase.from('addresses').select('*').eq('profile_id', pid);
      if (error) console.error("DB Error (addresses get):", error);
      
      return (data || []).map(addr => {
        if (addr.details && addr.details.includes('\n---TAG:NAME:')) {
          addr.details = addr.details.split('\n---TAG:NAME:')[0];
        }
        return addr;
      });
    },
    add: async (addr) => {
      const pid = await getUserId();
      if (!pid) return null;
      
      const profile = await db.user.get();
      const userName = profile?.name || 'Unknown';
      
      const payload = { ...addr };
      if (payload.details) {
        payload.details = `${payload.details}\n---TAG:NAME:${userName}---`;
      }
      
      const { data, error } = await supabase.from('addresses').insert([{ ...payload, profile_id: pid }]).select().single();
      if (error) console.error("DB Error (addresses add):", error);
      return data;
    },
    update: async (id, addr) => {
      const payload = { ...addr };
      if (payload.details) {
        const profile = await db.user.get();
        const userName = profile?.name || 'Unknown';
        payload.details = `${payload.details}\n---TAG:NAME:${userName}---`;
      }
      const { data, error } = await supabase.from('addresses').update(payload).eq('id', id).select().single();
      if (error) console.error("DB Error (addresses update):", error);
      return data;
    },
    delete: async (id) => {
      const { error } = await supabase.from('addresses').delete().eq('id', id);
      if (error) console.error("DB Error (addresses delete):", error);
    },
    setDefault: async (id) => {
      const pid = await getUserId();
      if (!pid) return;
      await supabase.from('addresses').update({ is_default: false }).eq('profile_id', pid);
      const { error } = await supabase.from('addresses').update({ is_default: true }).eq('id', id);
      if (error) console.error("DB Error (addresses setDefault):", error);
    }
  },
  orders: {
    getAll: async () => {
      const pid = await getUserId();
      if (!pid) return [];
      const { data, error } = await supabase.from('orders').select('*').eq('profile_id', pid).order('created_at', { ascending: false });
      if (error) console.error("DB Error (orders get):", error);
      return data || [];
    },
    getById: async (id) => {
      const { data, error } = await supabase.from('orders').select('*').eq('id', id).single();
      return error ? null : data;
    },
    add: async (orderData) => {
      const pid = await getUserId();
      if (!pid) return null;
      const { data, error } = await supabase.from('orders').insert([{
        profile_id: pid,
        items: orderData.items,
        total: orderData.total,
        delivery_address: orderData.address,
        payment_method: orderData.paymentMethod,
        status: orderData.paymentMethod === 'UPI' ? 'Payment Pending' : 'Preparing',
        delivery_charge: orderData.deliveryCharge,
        small_cart_charge: orderData.smallCartCharge
      }]).select().single();
      if (error) {
        console.error("DB Error (orders add):", error);
        throw error;
      }
      return data;
    },
    getAllAdmin: async () => {
      // Fetch all orders with user profiles
      const { data, error } = await supabase.from('orders').select('*, profiles(name, phone)').order('created_at', { ascending: false });
      if (error) console.error("DB Error (orders getAllAdmin):", error);
      return data || [];
    },
    updateStatus: async (id, status) => {
      const { data, error } = await supabase.from('orders').update({ status }).eq('id', id).select().single();
      if (error) console.error("DB Error (orders updateStatus):", error);
      return data;
    },
    delete: async (id) => {
      const { error } = await supabase.from('orders').delete().eq('id', id);
      if (error) console.error("DB Error (orders delete):", error);
    }
  },
  paymentMethods: {
    getAll: async () => {
      return [
        { id: 1, method: 'UPI', details: 'sujal@upi' }
      ];
    }
  },
  categories: {
    getAll: async () => {
      const { data, error } = await supabase.from('categories').select('*').order('created_at', { ascending: true });
      if (error) console.error("DB Error (categories get):", error);
      return data || [];
    },
    add: async (category) => {
      const { data, error } = await supabase.from('categories').insert([category]).select().single();
      if (error) console.error("DB Error (categories add):", error);
      return data;
    },
    update: async (id, category) => {
      const { data, error } = await supabase.from('categories').update(category).eq('id', id).select().single();
      if (error) console.error("DB Error (categories update):", error);
      return data;
    },
    delete: async (id) => {
      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) console.error("DB Error (categories delete):", error);
    },
    uploadImage: async (file) => {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('category-images')
        .upload(filePath, file);
        
      if (uploadError) {
        console.error('Upload Error:', uploadError);
        return null;
      }
      
      const { data } = supabase.storage.from('category-images').getPublicUrl(filePath);
      return data.publicUrl;
    }
  },
  products: {
    getAll: async () => {
      const { data, error } = await supabase.from('products').select('*, categories(name)').order('created_at', { ascending: false });
      if (error) console.error("DB Error (products getAll):", error);
      
      return (data || []).map(p => {
        const is_carousel = p.name.includes('---TAG:CAROUSEL---');
        const is_grid = p.name.includes('---TAG:GRID---');
        const stickerMatch = p.name.match(/---STICKER:(.*?)---/);
        const sticker = stickerMatch ? stickerMatch[1] : null;
        let name = p.name.replace('---TAG:CAROUSEL---', '').replace('---TAG:GRID---', '').replace(/---STICKER:.*?---/g, '');
        return { ...p, name, is_carousel, is_grid, sticker };
      });
    },
    getByCategory: async (categoryId) => {
      const { data, error } = await supabase.from('products').select('*, categories(name)').eq('category_id', categoryId).order('created_at', { ascending: false });
      if (error) console.error("DB Error (products getByCategory):", error);
      
      return (data || []).map(p => {
        const is_carousel = p.name.includes('---TAG:CAROUSEL---');
        const is_grid = p.name.includes('---TAG:GRID---');
        const stickerMatch = p.name.match(/---STICKER:(.*?)---/);
        const sticker = stickerMatch ? stickerMatch[1] : null;
        let name = p.name.replace('---TAG:CAROUSEL---', '').replace('---TAG:GRID---', '').replace(/---STICKER:.*?---/g, '');
        return { ...p, name, is_carousel, is_grid, sticker };
      });
    },
    search: async (query) => {
      const { data, error } = await supabase.from('products').select('*').ilike('name', `%${query}%`).limit(20);
      if (error) console.error("DB Error (products search):", error);
      return (data || []).map(p => {
        const is_carousel = p.name.includes('---TAG:CAROUSEL---');
        const is_grid = p.name.includes('---TAG:GRID---');
        const stickerMatch = p.name.match(/---STICKER:(.*?)---/);
        const sticker = stickerMatch ? stickerMatch[1] : null;
        let name = p.name.replace('---TAG:CAROUSEL---', '').replace('---TAG:GRID---', '').replace(/---STICKER:.*?---/g, '');
        return { ...p, name, is_carousel, is_grid, sticker };
      });
    },
    add: async (product) => {
      const { is_carousel, is_grid, sticker, categories, ...dbProduct } = product;
      if (is_carousel) dbProduct.name = `${dbProduct.name}---TAG:CAROUSEL---`;
      if (is_grid) dbProduct.name = `${dbProduct.name}---TAG:GRID---`;
      if (sticker) dbProduct.name = `${dbProduct.name}---STICKER:${sticker}---`;
      
      const { data, error } = await supabase.from('products').insert([dbProduct]).select().single();
      if (error) console.error("DB Error (products add):", error);
      
      return data ? { ...data, name: product.name, is_carousel: !!is_carousel, is_grid: !!is_grid, sticker: sticker || null } : null;
    },
    update: async (id, product) => {
      const { is_carousel, is_grid, sticker, categories, ...dbProduct } = product;
      if (is_carousel) {
        dbProduct.name = `${dbProduct.name}---TAG:CAROUSEL---`;
      } else {
        dbProduct.name = dbProduct.name.replace('---TAG:CAROUSEL---', '');
      }
      if (is_grid) {
        dbProduct.name = `${dbProduct.name}---TAG:GRID---`;
      } else {
        dbProduct.name = dbProduct.name.replace('---TAG:GRID---', '');
      }
      
      dbProduct.name = dbProduct.name.replace(/---STICKER:.*?---/, '');
      if (sticker) {
        dbProduct.name = `${dbProduct.name}---STICKER:${sticker}---`;
      }
      
      const { data, error } = await supabase.from('products').update(dbProduct).eq('id', id).select().single();
      if (error) console.error("DB Error (products update):", error);
      
      return data ? { ...data, name: product.name, is_carousel: !!is_carousel, is_grid: !!is_grid, sticker: sticker || null } : null;
    },
    delete: async (id) => {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) console.error("DB Error (products delete):", error);
    },
    uploadImage: async (file) => {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(filePath, file);
        
      if (uploadError) {
        console.error('Upload Error:', uploadError);
        return null;
      }
      
      const { data } = supabase.storage.from('product-images').getPublicUrl(filePath);
      return data.publicUrl;
    }
  },
  carousel: {
    getAll: async () => {
      const { data, error } = await supabase.from('carousel_images').select('*').order('order_index', { ascending: true });
      if (error) console.error("DB Error (carousel getAll):", error);
      return data || [];
    },
    add: async (banner) => {
      const { data, error } = await supabase.from('carousel_images').insert([banner]).select().single();
      if (error) {
        console.error("DB Error (carousel add):", error);
        return banner; 
      }
      return data;
    },
    update: async (id, banner) => {
      const { data, error } = await supabase.from('carousel_images').update(banner).eq('id', id).select().single();
      if (error) console.error("DB Error (carousel update):", error);
      return data;
    },
    delete: async (id) => {
      const { error } = await supabase.from('carousel_images').delete().eq('id', id);
      if (error) console.error("DB Error (carousel delete):", error);
      return true;
    }
  },
  carts: {
    get: async () => {
      const pid = await getUserId();
      if (!pid) return [];
      const { data, error } = await supabase.from('carts').select('cart_data').eq('profile_id', pid).single();
      if (error && error.code !== 'PGRST116') { // PGRST116 = No rows returned
        console.error("DB Error (carts get):", error);
      }
      return data?.cart_data || [];
    },
    sync: async (cartArray) => {
      const pid = await getUserId();
      if (!pid) return;
      const { error } = await supabase.from('carts').upsert({ profile_id: pid, cart_data: cartArray, updated_at: new Date().toISOString() }, { onConflict: 'profile_id' });
      if (error) console.error("DB Error (carts sync):", error);
    },
    clear: async () => {
      const pid = await getUserId();
      if (!pid) return;
      const { error } = await supabase.from('carts').delete().eq('profile_id', pid);
      if (error) console.error("DB Error (carts clear):", error);
    }
  }
};
